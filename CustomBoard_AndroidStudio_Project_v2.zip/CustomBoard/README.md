# Custom Board — Android Studio source project

**Project name:** Custom Board  
**Package:** `com.customboard.app`

## Current implementation in this milestone
- Full-screen Android board and touch handwriting
- Ten selectable ink colours
- White, black, and green board backgrounds
- Tool palette can be hidden/shown; it hides when board writing starts
- Pen, eraser, highlighter, line, rectangle, square, cube, circle, triangle, and ruler/straight-line drawing
- Undo/Redo and Zoom In/Out controls
- Multiple pages, page list, page switching, guarded page deletion
- Three-finger horizontal swipe page navigation (must be tested on the target phone)
- Manual save dialog asks for lesson/class name; date/time are recorded automatically
- Editable JSON-based `.customboard` lesson file
- Multi-page PDF export and current-page PNG export
- Portrait/landscape follows Android screen orientation

## Build on Windows
1. Install Android Studio and Android SDK Platform 35.
2. Extract this ZIP.
3. Open the extracted `CustomBoard` folder in Android Studio.
4. Let Gradle sync finish, then choose **Build > Build APK(s)** or run on a connected phone.

## Important implementation status
This is a source-code milestone, **not a tested APK**. This environment does not have Android SDK/Gradle installed, so the project has not been compiled or device-tested here.

Still to implement before calling the app complete:
- Dedicated edge arrows and separate hidden page-thumbnail drawer
- Actual external-display presenter mode (projector clean board / phone controls)
- Import and annotate images and PDFs
- Text insertion, paste-image context menu and full lesson reopen/import flow
- Compass and rotator tools
- True book-page-turn animation
- Save/leave unsaved-work warning and broader device testing

Saved files are in the app-specific `Android/data/com.customboard.app/files/CustomBoard` directory. Access to this folder varies by Android device and file manager.
