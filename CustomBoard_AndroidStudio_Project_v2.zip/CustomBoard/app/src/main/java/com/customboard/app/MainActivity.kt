package com.customboard.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private lateinit var palette: LinearLayout
    private lateinit var pagePanel: LinearLayout
    private lateinit var root: LinearLayout
    private var paletteVisible = true
    private var pagesVisible = false
    private var pageIndex = 0
    private val pages = mutableListOf<MutableList<Stroke>>()
    private val redoPages = mutableListOf<MutableList<Stroke>>()
    private var currentColor = Color.BLACK
    private var backgroundColor = Color.WHITE
    private var currentTool = "Pen"
    private var lessonName = "Untitled"
    private val colors = listOf(
        Color.BLACK, Color.WHITE, Color.RED, Color.BLUE, Color.GREEN,
        Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.rgb(255, 140, 0), Color.rgb(120, 70, 200)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        pages.add(mutableListOf())
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.DKGRAY)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
            setBackgroundColor(Color.rgb(35, 39, 45))
        }
        fun topButton(label: String, action: () -> Unit) {
            top.addView(Button(this).apply {
                text = label
                textSize = 11f
                setPadding(dp(5), 0, dp(5), 0)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        topButton("☰ Tools") { togglePalette() }
        topButton("Pages") { togglePages() }
        topButton("Undo") { undo() }
        topButton("Redo") { redo() }
        topButton("−") { board.changeZoom(0.85f) }
        topButton("+") { board.changeZoom(1.18f) }
        topButton("Save") { saveLessonDialog() }
        topButton("PDF") { exportPdf() }
        topButton("Image") { exportImage() }
        root.addView(top)

        palette = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(4))
            setBackgroundColor(Color.rgb(225, 228, 232))
        }
        val toolRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Pen", "Eraser", "Highlighter", "Line", "Rect", "Square", "Cube", "Circle", "Triangle", "Ruler").forEach { tool ->
            toolRow.addView(Button(this).apply {
                text = tool
                textSize = 10f
                setPadding(dp(3), 0, dp(3), 0)
                setOnClickListener {
                    currentTool = tool
                    Toast.makeText(this@MainActivity, "$tool தேர்வு செய்யப்பட்டது", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        palette.addView(toolRow)

        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEachIndexed { i, color ->
            colorRow.addView(View(this).apply {
                setBackgroundColor(color)
                setOnClickListener {
                    currentColor = color
                    if (color == backgroundColor) {
                        Toast.makeText(this@MainActivity, "எழுதும் நிறமும் பின்னணி நிறமும் ஒன்றாக உள்ளது", Toast.LENGTH_SHORT).show()
                    }
                }
                contentDescription = "நிறம் ${i + 1}"
            }, LinearLayout.LayoutParams(0, dp(30), 1f).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        palette.addView(colorRow)

        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("White", "Black", "Green").forEach { label ->
            options.addView(Button(this).apply {
                text = "BG $label"
                textSize = 10f
                setOnClickListener {
                    backgroundColor = when (label) {
                        "Black" -> Color.BLACK
                        "Green" -> Color.rgb(0, 100, 0)
                        else -> Color.WHITE
                    }
                    board.invalidate()
                }
            }, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        options.addView(Button(this).apply {
            text = "New page"
            textSize = 10f
            setOnClickListener { addOrNextPage() }
        }, LinearLayout.LayoutParams(0, dp(38), 1f))
        options.addView(Button(this).apply {
            text = "Clear page"
            textSize = 10f
            setOnClickListener { clearPage() }
        }, LinearLayout.LayoutParams(0, dp(38), 1f))
        palette.addView(options)
        root.addView(palette)

        pagePanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(3), dp(4), dp(3))
            setBackgroundColor(Color.rgb(245, 245, 245))
            visibility = View.GONE
        }
        root.addView(pagePanel)

        board = BoardView()
        root.addView(board, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        refreshPages()
    }

    private fun togglePalette() {
        paletteVisible = !paletteVisible
        palette.visibility = if (paletteVisible) View.VISIBLE else View.GONE
    }

    private fun togglePages() {
        pagesVisible = !pagesVisible
        pagePanel.visibility = if (pagesVisible) View.VISIBLE else View.GONE
        refreshPages()
    }

    private fun refreshPages() {
        if (!::pagePanel.isInitialized) return
        pagePanel.removeAllViews()
        pages.forEachIndexed { idx, _ ->
            pagePanel.addView(Button(this).apply {
                text = "Page ${idx + 1}${if (idx == pageIndex) " ✓" else ""}"
                textSize = 11f
                setOnClickListener {
                    pageIndex = idx
                    board.invalidate()
                    refreshPages()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Delete Page ${idx + 1}?")
                        .setMessage("இந்தப் பக்கத்தில் உள்ள உள்ளடக்கம் நீக்கப்படும்.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete") { _, _ ->
                            if (pages.size > 1) {
                                pages.removeAt(idx)
                                pageIndex = pageIndex.coerceAtMost(pages.lastIndex)
                                board.invalidate()
                                refreshPages()
                            } else {
                                pages[0].clear()
                                board.invalidate()
                            }
                        }.show()
                    true
                }
            }, LinearLayout.LayoutParams(dp(110), dp(42)))
        }
        pagePanel.addView(Button(this).apply {
            text = "+ Page"
            setOnClickListener { addOrNextPage() }
        })
    }

    private fun addOrNextPage() {
        if (pageIndex < pages.lastIndex) {
            pageIndex++
        } else {
            pages.add(mutableListOf())
            pageIndex = pages.lastIndex
        }
        board.invalidate()
        refreshPages()
    }

    private fun undo() {
        val page = pages[pageIndex]
        if (page.isNotEmpty()) {
            redoPages.add(page.removeAt(page.lastIndex))
            board.invalidate()
        }
    }

    private fun redo() {
        if (redoPages.isNotEmpty()) {
            pages[pageIndex].add(redoPages.removeAt(redoPages.lastIndex))
            board.invalidate()
        }
    }

    private fun clearPage() {
        AlertDialog.Builder(this).setTitle("Clear current page?")
            .setMessage("இந்தப் பக்கத்தின் அனைத்து வரைவுகளும் நீக்கப்படும்.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                pages[pageIndex].clear()
                board.invalidate()
            }.show()
    }

    private fun saveLessonDialog() {
        val input = EditText(this).apply {
            hint = "வகுப்பு / பாடத்தின் பெயர்"
            setText(lessonName.takeUnless { it == "Untitled" } ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("Save Custom Board lesson")
            .setMessage("பாடத்தின் பெயரை மட்டும் உள்ளிடவும். தேதி, நேரம் தானாகச் சேர்க்கப்படும்.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Lesson" }
                lessonName = name
                val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault()).format(Date())
                val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val dir = outputDir()
                val json = JSONObject().apply {
                    put("app", "Custom Board")
                    put("lesson", name)
                    put("savedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
                    put("backgroundColor", backgroundColor)
                    put("pages", JSONArray().apply {
                        pages.forEach { page ->
                            put(JSONArray().apply {
                                page.forEach { stroke ->
                                    put(JSONObject().apply {
                                        put("color", stroke.color)
                                        put("width", stroke.width)
                                        put("tool", stroke.tool)
                                        put("points", JSONArray().apply {
                                            stroke.points.forEach { p ->
                                                put(JSONArray().put(p.first).put(p.second))
                                            }
                                        })
                                    })
                                }
                            })
                        }
                    })
                }
                File(dir, "${safeName}_$stamp.customboard").writeText(json.toString(2), Charsets.UTF_8)
                Toast.makeText(this, "பாடம் சேமிக்கப்பட்டது: ${dir.absolutePath}", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun outputDir(): File {
        val dir = File(getExternalFilesDir(null) ?: filesDir, "CustomBoard")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun exportImage() {
        val bmp = board.renderBitmap()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(outputDir(), "CustomBoard_Page${pageIndex + 1}_$stamp.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        Toast.makeText(this, "படம் சேமிக்கப்பட்டது: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun exportPdf() {
        val pdf = PdfDocument()
        val w = 1200
        val h = 1600
        pages.forEachIndexed { index, strokes ->
            val info = PdfDocument.PageInfo.Builder(w, h, index + 1).create()
            val page = pdf.startPage(info)
            page.canvas.drawColor(backgroundColor)
            drawStrokes(page.canvas, strokes, w.toFloat(), h.toFloat())
            pdf.finishPage(page)
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(outputDir(), "CustomBoard_$stamp.pdf")
        FileOutputStream(file).use { pdf.writeTo(it) }
        pdf.close()
        Toast.makeText(this, "பல்பக்க PDF சேமிக்கப்பட்டது: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun drawStrokes(canvas: Canvas, strokes: List<Stroke>, width: Float, height: Float) {
        val scaleX = width / (board.width.coerceAtLeast(1).toFloat())
        val scaleY = height / (board.height.coerceAtLeast(1).toFloat())
        strokes.forEach { s ->
            if (s.points.isEmpty()) return@forEach
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (s.tool == "Eraser") backgroundColor else s.color
                strokeWidth = s.width * ((scaleX + scaleY) / 2f)
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                if (s.tool == "Highlighter") alpha = 85
            }
            val path = Path()
            val firstX = s.points[0].first * scaleX
            val firstY = s.points[0].second * scaleY
            path.moveTo(firstX, firstY)
            if (s.points.size == 1) {
                path.lineTo(firstX + 0.1f, firstY + 0.1f)
            } else if (s.tool == "Rect" || s.tool == "Ruler" || s.tool == "Line" ||
                s.tool == "Circle" || s.tool == "Triangle" || s.tool == "Square" || s.tool == "Cube") {
                val last = s.points.last()
                val x2 = last.first * scaleX
                val y2 = last.second * scaleY
                when (s.tool) {
                    "Line", "Ruler" -> {
                        path.lineTo(x2, y2)
                    }
                    "Rect" -> {
                        path.addRect(firstX, firstY, x2, y2, Path.Direction.CW)
                    }
                    "Square" -> {
                        val side = maxOf(kotlin.math.abs(x2 - firstX), kotlin.math.abs(y2 - firstY))
                        path.addRect(firstX, firstY, firstX + side, firstY + side, Path.Direction.CW)
                    }
                    "Circle" -> {
                        val left = minOf(firstX, x2)
                        val top = minOf(firstY, y2)
                        val right = maxOf(firstX, x2)
                        val bottom = maxOf(firstY, y2)
                        path.addOval(left, top, right, bottom, Path.Direction.CW)
                    }
                    "Triangle" -> {
                        path.moveTo((firstX + x2) / 2f, firstY)
                        path.lineTo(x2, y2)
                        path.lineTo(firstX, y2)
                        path.close()
                    }
                    "Cube" -> {
                        val dx = (x2 - firstX) * 0.30f
                        val dy = (y2 - firstY) * 0.22f
                        path.moveTo(firstX, firstY + dy)
                        path.lineTo(firstX + dx, firstY)
                        path.lineTo(x2, firstY)
                        path.lineTo(x2, y2 - dy)
                        path.lineTo(x2 - dx, y2)
                        path.lineTo(firstX, y2)
                        path.close()
                        path.moveTo(firstX, firstY + dy)
                        path.lineTo(firstX + dx, firstY)
                        path.lineTo(firstX + dx, y2 - dy)
                        path.lineTo(x2, y2 - dy)
                        path.moveTo(firstX + dx, y2 - dy)
                        path.lineTo(firstX, y2)
                    }
                }
            } else {
                for (i in 1 until s.points.size) {
                    path.lineTo(s.points[i].first * scaleX, s.points[i].second * scaleY)
                }
            }
            canvas.drawPath(path, paint)
        }
    }

    private data class Stroke(
        val color: Int,
        val width: Float,
        val tool: String,
        val points: MutableList<Pair<Float, Float>> = mutableListOf()
    )

    private inner class BoardView : View(this@MainActivity) {
        private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private var activeStroke: Stroke? = null
        private var zoom = 1f
        private var threeFingerStartX = 0f
        private var threeFingerStartY = 0f
        private var threeFingerHandled = false

        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

        fun changeZoom(factor: Float) {
            zoom = (zoom * factor).coerceIn(0.5f, 3f)
            invalidate()
        }

        fun renderBitmap(): Bitmap {
            val bmp = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(backgroundColor)
            drawStrokes(c, pages[pageIndex], width.toFloat(), height.toFloat())
            return bmp
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(backgroundColor)
            canvas.save()
            canvas.scale(zoom, zoom, width / 2f, height / 2f)
            drawStrokes(canvas, pages[pageIndex], width.toFloat(), height.toFloat())
            activeStroke?.let { drawStrokes(canvas, listOf(it), width.toFloat(), height.toFloat()) }
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.pointerCount >= 3 || threeFingerHandled) {
                if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN && event.pointerCount >= 3) {
                    threeFingerStartX = event.getX(0)
                    threeFingerStartY = event.getY(0)
                    threeFingerHandled = false
                }
                if (event.actionMasked == MotionEvent.ACTION_POINTER_UP && event.pointerCount >= 3 && !threeFingerHandled) {
                    val dx = event.getX(0) - threeFingerStartX
                    val dy = event.getY(0) - threeFingerStartY
                    if (kotlin.math.abs(dx) > dp(70) && kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                        if (dx < 0) addOrNextPage() else if (pageIndex > 0) { pageIndex--; invalidate(); refreshPages() }
                        threeFingerHandled = true
                    }
                }
                if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                    threeFingerHandled = false
                }
                return true
            }
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activeStroke = Stroke(
                        color = currentColor,
                        width = if (currentTool == "Highlighter") 18f else if (currentTool == "Eraser") 28f else 5f,
                        tool = currentTool
                    ).also { it.points.add(Pair(event.x / zoom, event.y / zoom)) }
                    if (paletteVisible) {
                        paletteVisible = false
                        palette.visibility = View.GONE
                    }
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    activeStroke?.points?.add(Pair(event.x / zoom, event.y / zoom))
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    activeStroke?.let { stroke ->
                        if (stroke.points.size == 1) stroke.points.add(stroke.points[0])
                        pages[pageIndex].add(stroke)
                    }
                    activeStroke = null
                    threeFingerHandled = false
                    invalidate()
                    return true
                }
            }
            return true
        }
    }
}
